<?php

$SMTPuser = 'jaybhayesuraj7@gmail.com';   
$SMTPpwd = 'suraj112003055'; 
$SMTPtitle = "SOLVEIT inc.";
$Domain = 'localhost';

